class DojosController < ApplicationController
  def show
  	@dojo = Dojo.all
  end
  def new
  	
  end
  def create
  	Dojo.create(state:params[:state], city:params[:city], branch:params[:branch], street:params[:street])
  	redirect_to "/dojos/show"
  end
end
