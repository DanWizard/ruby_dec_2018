Rails.application.routes.draw do
get "time" => 'times#display' 
end
