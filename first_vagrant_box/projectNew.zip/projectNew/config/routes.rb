Rails.application.routes.draw do
  get 'sessions/register' => 'sessions#new'
  get 'sessions/login' => 'sessions#login'
  post 'sessions/register' => 'sessions#create'
  post 'sessions/login' => 'sessions#verify'
  get 'sessions/home' => 'sessions#home'
  
end
