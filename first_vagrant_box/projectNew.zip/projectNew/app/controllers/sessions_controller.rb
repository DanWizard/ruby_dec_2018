class SessionsController < ApplicationController
  def login
	session[:user_id] = nil
	p session[:user_id]
  end
  def new
  	session[:user_id] = nil
  	p session[:user_id]
  end
  def create
  	begin
        User.create(name:params[:name], email:params[:email], password:params[:password], password_confirmation:params[:confirm_passord])
        session[:user_id] = User.last.id
        p session[:user_id]
        p "success"
        redirect_to '/sessions/home'
    rescue
    	p "fail"
    	redirect_to '/sessions/register'
    end
  end
  def home
  end
  def verify
  	begin
  		u = User.find_by_email(params[:email]).try(:authenticate, params[:password])
  		session[:user_id] = u.id
  		p session[:user_id]
  		redirect_to '/sessions/home'
  	rescue
  		p "fail"
  		redirect_to '/sessions/login'
  	end
  end
end
