class DojosController < ApplicationController
  def show
  	@dojo = Dojo.all
  end
  def new
  	
  end
  def create
  	Dojo.create(state:params[:state], city:params[:city], branch:params[:branch], street:params[:street])
  	redirect_to "/dojos/show"
  end
  def destroy
  	Dojo.find(params[:id]).destroy
  	redirect_to "/dojos/show"
  end
  def showOne
  	@dojo = Dojo.find(params[:id])
  end
  def showEdit
  	@dojo = Dojo.find(params[:id])
  end
  def edit
  	Dojo.update(params[:id], state:params[:state], city:params[:city], branch:params[:branch], street:params[:street])
  	redirect_to "/dojos/show"
  end
end
