class DojosController < ApplicationController
  def show
  	@dojo = Dojo.all
  end
end
