class Message < ActiveRecord::Migration
  def change
  end
end
