class Message < ActiveRecord::Base
	 belongs_to :post
end
