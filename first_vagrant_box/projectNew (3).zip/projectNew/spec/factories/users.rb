FactoryBot.define do
  factory :user do
    name { "MyString" }
    password { "" }
  end
end
