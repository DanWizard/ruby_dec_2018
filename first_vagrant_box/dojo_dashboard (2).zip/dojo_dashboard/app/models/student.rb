class Student < ActiveRecord::Base
  belongs_to :user
end
